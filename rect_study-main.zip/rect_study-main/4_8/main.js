const myName = "minjun"
const email = "dhakla3@gmail.com"
const hello = `Hello ${myName}??`

console.log(hello)

const number = 10;
const number2 = 10.55;

const checked = True;
const isShow = false;

let undef;
const obj = {abc:123};
console.log(undef);
console.log(obj.abc);
console.log(obj.xyz);

console.log(name);

const user = {
    userName : "jh",
    age : 31,
    isValid : True
}

const user = {
};
console.log(user.userName);
console.log(user.age);
console.log(user.isValid);

const fruits = ['Apple' , 'Banana' , 'Cherry'];
console.log(fruits[0]);

isShow = true;
if (isShow) {
    var aaa = "A";
    console.log(aaa);
}
abc();

console.log(aaa);

const a = 12;
console.log(a);
a = 999;
console.log(a);
