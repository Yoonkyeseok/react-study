import logo from './logo.svg';
import './App.css';
import Say from './say'


const App = () => {
  return <Say />;
};

export default App;
