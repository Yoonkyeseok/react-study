import { useState } from "react";

const Event2 = () => {
    const [form, setform] = useState({
        username: '',
        message: ''

    });
    const {username, message} = form;
    const onChange = e => {
        
    }
}