let pi = 3.141592
console.log(`test.js의 pi는${pi}`);
